# Projet_1SN
Pour ce premier rendu seul ces fichiers auront un usage : 
1. module table de routage ( qui va contenir toutes les procedure et fonction utile pour construire une table de routage simple)
table_routage.adb 
table_routage.ads

2. module qui contient différente fonction/procedure/ type qui permette de manipuler ou de donnée des info sur la table de routage manipulée 
tools.adb
tools.ads

3. Des test du module table_routage, avec un fichier test.txt qui contient les infos de la table de routage 
test_table_routage.adb 
test.txt

4. exemple d'utilisation d'une table de routage 
main.adb


Vous pouvez compiler test_table_routage.adb et main.adb pour ce premier rendu

